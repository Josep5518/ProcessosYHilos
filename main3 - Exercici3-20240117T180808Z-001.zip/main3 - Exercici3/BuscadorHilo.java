package HilosYProcesosPt2;

class BuscadorHilo extends Thread {
    // Campos que almacenan la información necesaria para la búsqueda
    private final int[] vector;     
    private final int numeroBuscar;  
    private final int inicio;        
    private final int fin;           
    private final int id;            

    // Constructor que inicializa los campos de la clase
    public BuscadorHilo(int[] vector, int numeroBuscar, int inicio, int fin, int id) {
        this.vector = vector;
        this.numeroBuscar = numeroBuscar;
        this.inicio = inicio;
        this.fin = fin;
        this.id = id;
    }

    // Método run() que se ejecutará cuando se inicie el hilo
    @Override
    public void run() {
       
        int resultado = buscarEnVector();
        // Si se encuentra el número, imprime un mensaje con la posición y el identificador del hilo
        if (resultado != -1) {
            System.out.println("El valor " + numeroBuscar + " se ha encontrado en la posición " + resultado + " (hilo " + id + ").");
        }
    }

    // Este es el método privado que realiza la búsqueda en el vector en el rango asignado
    private int buscarEnVector() {
        
        for (int i = inicio; i <= fin; i++) {
            // Si encuentra el número, devuelve la posición
            if (vector[i] == numeroBuscar) {
                return i;
            }
        }
        return -1;
    }
}
