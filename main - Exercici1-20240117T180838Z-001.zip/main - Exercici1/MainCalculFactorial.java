package main;
import java.util.Scanner;

public class MainCalculFactorial {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese la cantidad de números para calcular el factorial: ");
        int numero = scanner.nextInt();

        if (numero <= 0) {
            System.out.println("La cantidad de números debe ser mayor que cero.");
            return;
        }

        int[] numeros = new int[numero];

        System.out.println("Ingrese los números uno por uno:");

        for (int i = 0; i < numero; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        CalculFactorial[] hilos = new CalculFactorial[numero];

        for (int i = 0; i < numero; i++) {
            hilos[i] = new CalculFactorial(numeros[i]);
            hilos[i].start();
        }

        // Esperar a que todos los hilos finalicen antes de imprimir los resultados
        for (CalculFactorial hilo : hilos) {
            try {
                hilo.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("FIN.");
    }
}