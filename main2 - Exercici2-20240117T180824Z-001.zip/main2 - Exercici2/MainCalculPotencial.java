package main2;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainCalculPotencial {
	public static void main(String[] args) {	

		// Crea un objeto Scanner para leer la entrada del usuario desde la consola
		Scanner scanner = new Scanner(System.in);

		// Solicita al usuario que ingrese el número de hilos
		System.out.print("Ingrese el número de hilos: ");

		// Lee el número de hilos desde la consola
		int numThreads = scanner.nextInt();
		numThreads = numThreads - 1;
		// Cierra el  objeto Scanner después de su uso
		scanner.close();

		// Verifica que el número de hilos sea positivo
		if (numThreads <= 0) {
			System.out.println("El número de hilos debe ser un entero positivo.");
		}


		// Crea un arreglo de hilos
		Thread[] threads = new Thread[numThreads];

		// Bucle para crear y empezar cada hilo, cada uno calculando una potencia de 2 diferente
		for (int i = 0; i < numThreads; i++) {
			threads[i] = new Thread(new CalculPotencial(i));
			threads[i].start();
		}

		try {
			// Espera a que todos los hilos terminen usando el método join()
			for (Thread thread : threads) {
				thread.join();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		   System.out.println("FIN.");
	}
}

