package HilosYProcesosPt2;

import java.util.Scanner;

public class Buscador {
    public static void main(String[] args) {
        // Se crea un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        // Se solicita al usuario que introduzca el tamaño del vector, el número a buscar y el número de hilos
        System.out.print("Introduce el tamaño del vector, el número a buscar y el número de hilos (separados por espacios): ");
        
        String input = scanner.nextLine();
        System.out.println(" ");
        
        String[] parametros = input.split("\\s+");

        // Se verifica que se hayan introducido exactamente 3 números separados por espacios
        if (parametros.length != 3) {
            System.out.println("Debes introducir exactamente 3 números separados por espacios.");
            System.exit(1);
        }
        int tamañoVector = Integer.parseInt(parametros[0]);
        int numeroBuscar = Integer.parseInt(parametros[1]);
        int numeroHilos = Integer.parseInt(parametros[2]);

        // Se comprueba que el tamaño del vector y el número de hilos sean mayores que cero
        if (tamañoVector <= 0 || numeroHilos <= 0) {
            System.out.println("El tamaño del vector y el número de hilos deben ser mayores que cero.");
            System.exit(1);
        }

        // Se crea un vector de enteros y se llena con valores aleatorios entre 0 y 99
        int[] vector = new int[tamañoVector];
        for (int i = 0; i < tamañoVector; i++) {
            vector[i] = (int) (Math.random() * 100);
        }

        // Se calcula el número de elementos por hilo y la posición inicial para el hilo padre
        int elementosPorHilo = tamañoVector / (numeroHilos + 1);
        int posicionInicialPadre = tamañoVector - (elementosPorHilo * numeroHilos);

        // Se crea un arreglo de hilos para realizar la búsqueda
        BuscadorHilo[] hilos = new BuscadorHilo[numeroHilos];
        for (int i = 0; i < numeroHilos; i++) {
            
            int posicionInicial = i * elementosPorHilo;
            int posicionFinal = posicionInicial + elementosPorHilo - 1;
            // Se crea un objeto BuscadorHilo con los parámetros calculados y se inicia el hilo
            hilos[i] = new BuscadorHilo(vector, numeroBuscar, posicionInicial, posicionFinal, i);
            hilos[i].start();
        }

        // Se realiza una búsqueda secuencial en el hilo padre en el rango asignado
        int posicion = buscarEnVector(vector, numeroBuscar, posicionInicialPadre, tamañoVector - 1);

        // Se espera a que todos los hilos terminen su ejecución
        for (BuscadorHilo hilo : hilos) {
            try {
                hilo.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Se muestra el resultado de la búsqueda
        mostrarResultado(numeroBuscar, posicion);

        scanner.close();
    }

    //Este es el método privado que realiza una búsqueda secuencial en un vector en un rango específico
    private static int buscarEnVector(int[] vector, int numeroBuscar, int inicio, int fin) {
        for (int i = inicio; i <= fin; i++) {
            if (vector[i] == numeroBuscar) {
                return i;
            }
        }
        return -1;
    }

    // Aqui muestra el resultado de la búsqueda
    private static void mostrarResultado(int numeroBuscar, int posicion) {
    	System.out.println(" ");
        System.out.println("Resultado de la búsqueda:");
        System.out.println(" ");
        if (posicion != -1) {
            System.out.println("El valor " + numeroBuscar + " se ha encontrado en la posición " + posicion + " (proceso padre).");
        } else {
            System.out.println("El valor " + numeroBuscar + " no se ha encontrado.");
        }
    }
}
