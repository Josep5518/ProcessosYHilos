package main2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CalculPotencial implements Runnable, Comparable<CalculPotencial> {
    private int exponent;


 // Constructora que recibe el exponente como parámetro
    public CalculPotencial(int exponent) {
        this.exponent = exponent;
    }
 // método run() implementado desde la interfaz Runnable, calcula la potencia de 2 e imprime el resultado
    @Override
    public void run() {
        long result = (long) Math.pow(2, exponent);
        System.out.println("2^" + exponent + " = " + result);
    }

 // método compareTo() de la interfaz Comparable para definir el orden natural basado en el exponente
    @Override
    public int compareTo(CalculPotencial other) {
        return Integer.compare(this.exponent, other.exponent);
    }
}