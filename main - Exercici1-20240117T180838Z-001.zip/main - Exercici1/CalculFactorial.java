package main;

public class CalculFactorial extends Thread {
    // Variable para almacenar el número para el cual se calculará el factorial
    private int numero;

    // Constructor que recibe el número para calcular el factorial
    public CalculFactorial(int numero) {
        this.numero = numero;
    }

    // Método run, que se ejecutará cuando se inicie el hilo
    @Override
    public void run() {
        // Calcular el factorial del número
        long factorial = calcularFactorial(numero);

        // Imprimir el resultado del cálculo del factorial
        System.out.println("Factorial de " + numero + ": " + factorial);
    }

    // Método privado para calcular el factorial de un número
    private long calcularFactorial(int n) {
        // Casos base: 0! y 1! son ambos 1
        if (n == 0 || n == 1) {
            return 1;
        } else {
     
            long factorial = 1;
            // Calcular el factorial utilizando un bucle for
            for (int i = 2; i <= n; i++) {
                factorial *= i;
            }

            // Devolver el resultado del cálculo del factorial
            return factorial;
        }
    }

    // Método main para mostrar un ejemplo de uso
    public static void main(String[] args) {
        int numero = 5;

        // Crear una instancia de CalculFactorial con el número especificado
        CalculFactorial calculador = new CalculFactorial(numero);

        // Iniciar el hilo para calcular el factorial
        calculador.start();
    }
}